﻿using System;

class Program
{
    static void Main()
    {

        Console.Write("Введите число: ");

        string input = Console.ReadLine();

        double number = int.Parse(input);

        Console.WriteLine("Вы ввели число: " + number);

    }
}
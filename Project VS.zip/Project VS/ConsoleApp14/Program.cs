﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("5 10, 7см");
    }
}
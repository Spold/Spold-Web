﻿using System;

class Program
{
    static void Main()
    {
        int number1 = 10;
        int number2 = 20;
        int number3 = 30;

        Console.WriteLine(number1 + "  " + number2 + "  " + number3);

    }
}

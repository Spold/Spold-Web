﻿using System;

class Program
{
    static void Main()
    {
        Random random = new Random();

        int number1 = random.Next(0, 10);
        int number2 = random.Next(0, 10);
        int number3 = random.Next(0, 10);
        int number4 = random.Next(0, 10);

        Console.WriteLine(number1);
        Console.WriteLine(number2);
        Console.WriteLine(number3);
        Console.WriteLine(number4);
    }
}

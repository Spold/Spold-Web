﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("50");
        Console.WriteLine("10");
    }
}
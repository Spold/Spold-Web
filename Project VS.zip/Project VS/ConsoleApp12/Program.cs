﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("5");
        Console.WriteLine("10");
        Console.WriteLine("21");
    }
}